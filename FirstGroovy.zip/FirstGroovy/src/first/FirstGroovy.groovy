package first

class FirstGroovy {
	static void main(def args){
        def mylist= [1,2,"Lars","4"]
        mylist.each{ println it }
    }

}

