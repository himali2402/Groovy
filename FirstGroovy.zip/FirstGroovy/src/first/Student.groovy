package first

class Student extends Person {
    int StudentID
    int Marks1;

    public Student() {
        super();
    }
}
