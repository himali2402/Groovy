package first

class GroovyIf {
	static void main(String[] args) {
		// Initializing a local variable
		def a = 2

		//Check for the boolean condition
		if (a<100) {
			println("The value is less than 100");
		} else {
			println("The value is greater than 100");
		}
	}
}
