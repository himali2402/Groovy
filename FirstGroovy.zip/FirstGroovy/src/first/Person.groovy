package first

class Person {
	public String name;
	public Person() {}
}
